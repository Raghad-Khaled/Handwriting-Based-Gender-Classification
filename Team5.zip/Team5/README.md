# Anconda version 3.8.5
# dotenv library
# Github repo : https://github.com/Raghad-Khaled/Handwriting-Based-Gender-Classification
